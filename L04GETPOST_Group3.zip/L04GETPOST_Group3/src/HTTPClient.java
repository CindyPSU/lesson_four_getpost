
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

/**
 *
 * @author Group 3
 */
public class HTTPClient {
    
    public HTTPClient() {
        System.out.println("HTTP Client Started");  
    }
    // Sets up a separate connection for GET
    public void GET() {
        try {
            InetAddress serverInetAddress = 
               InetAddress.getByName("127.0.0.1");
            Socket connection = new Socket(serverInetAddress, 80);

            try (OutputStream out = connection.getOutputStream();
                 BufferedReader in = 
                     new BufferedReader(new 
                         InputStreamReader(
                             connection.getInputStream()))) {
                sendGet(out);
                System.out.println(getResponse(in));
            }
        } catch (IOException ex) {
            //Handle code
        }
    }
    
    // Sets up a separate connection for POST       
    public void POST(){
        try {
            InetAddress serverInetAddress = 
               InetAddress.getByName("127.0.0.1");
            Socket connection = new Socket(serverInetAddress, 80);

            try (OutputStream out = connection.getOutputStream();
                 BufferedReader in = 
                     new BufferedReader(new 
                         InputStreamReader(
                             connection.getInputStream()))) {
                sendPost(out);
                System.out.println(getResponse(in));
            }
        } catch (IOException ex) {
            //Handle code
        }
    }
    
    // Sends these lines to the server:
    // GET /default
    // User-Agent: Mozilla/5.0
    private void sendGet(OutputStream out) {
        try {
            out.write("GET /default\r\n".getBytes());
            out.write("User-Agent: Mozilla/5.0\r\n".getBytes());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    // Sends these lines to the server:
    // POST /default
    // User-Agent: Mozilla/5.0
    //
    // Diary entry here
    // Requirement 4: POST a string of text to the diary
    private void sendPost(OutputStream out){
        try {
            out.write("POST /default\r\n".getBytes());
            out.write("User-Agent: Mozilla/5.0\r\n".getBytes());
            out.write("\r\n".getBytes());
            out.write("It's been a long week \r\n".getBytes());
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        HTTPClient client = new HTTPClient();
        client.POST();
        client.GET();
    }
    
    private String getResponse(BufferedReader in) {
        try {
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine).append("\n");
            }
            return response.toString();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "";
    }
}
