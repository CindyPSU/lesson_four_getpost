
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.StringTokenizer;

/**
 *
 * @author Group 3
 */
public class ClientHandler implements Runnable {
    
    private final Socket socket;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        System.out.println("\nClientHandler Started for " + 
            this.socket);
        handleRequest(this.socket);
        System.out.println("ClientHandler Terminated for " 
            + this.socket + "\n");
    }

    public void handleRequest(Socket socket) {
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(socket.getInputStream()));) {
            String headerLine = in.readLine();
            StringTokenizer tokenizer = 
                new StringTokenizer(headerLine);
            String httpMethod = tokenizer.nextToken();
            // Requirement 3: GET method
            if (httpMethod.equals("GET")) {
                getDiary(tokenizer);
            }
            else if (httpMethod.equals("POST")) {
                postDiary(in);
            }
            else {
                    System.out.println("The HTTP method is not recognized");
                    sendResponse(socket, 405, "Method Not Allowed");
                }        
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
            
    
    public void getDiary(StringTokenizer tokenizer) {
        System.out.println("GET method processed");
        String httpQueryString = tokenizer.nextToken();
        try {
            // Find diary file
            File f = new File("diary.txt");
            char[] cbuff;
            if(f.exists()){
                // Allocating buffer to hold contents of diary
                cbuff = new char[(int)f.length()]; 
                // Open diary.txt and copy everything into the buffer
                FileReader fr = new FileReader("diary.txt");
                fr.read(cbuff);
                fr.close();
            } else {
                System.out.println("File not found.");
                cbuff = new char[0];
            }
            // Requirement 3/4: Displays the entire contents of the diary.    
            StringBuilder responseBuffer = new StringBuilder();
            responseBuffer
                .append("<html><h1>Group 3 Diary</h1><br>")
                .append("<b>Welcome to our diary!</b><BR>")
                //Data in buffer will be appended to the response that comes back
                .append(cbuff)
                .append("</html>");
            sendResponse(socket, 200, responseBuffer.toString());
        }
        catch (IOException ex){
            ex.printStackTrace();
        }
    }
    // Requirement 1: Handle the case that HTTP method equals "POST"        
    public void postDiary(BufferedReader in){ 
        try {
            String data;
            while(true){
              String nextLine = in.readLine();
              if(nextLine.equals("")) {
                  data = in.readLine();
                  break;
              }
            }
            // Requirement 2: Update a file on the server containing all of the diary posts.
            FileWriter fw = new FileWriter("diary.txt", true);
            fw.write("<p>"+data+"</p>\r\n");
            fw.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
        public void sendResponse(Socket socket, int statusCode, String responseString) {
        String statusLine;
        String serverHeader = "HTTPServer: WebServer\r\n";
        String contentTypeHeader = "Content-Type: text/html\r\n";

        try (DataOutputStream out = 
                new DataOutputStream(socket.getOutputStream());) {
            if (statusCode == 200) {
                statusLine = "HTTP/1.0 200 OK" + "\r\n";
                String contentLengthHeader = "Content-Length: " 
                    + responseString.length() + "\r\n";

                out.writeBytes(statusLine);
                out.writeBytes(serverHeader);
                out.writeBytes(contentTypeHeader);
                out.writeBytes(contentLengthHeader);
                out.writeBytes("\r\n");
                out.writeBytes(responseString);
            } else if (statusCode == 405) {
                statusLine = "HTTP/1.0 405 Method Not Allowed" + "\r\n";
                out.writeBytes(statusLine);
                out.writeBytes("\r\n");
            } else {
                statusLine = "HTTP/1.0 404 Not Found" + "\r\n";
                out.writeBytes(statusLine);
                out.writeBytes("\r\n");
            }
            out.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

